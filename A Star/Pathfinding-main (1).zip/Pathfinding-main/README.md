<p align="center"><img align="center" src="./neural.svg" width=100 height=100>
<h1 align="center">Pathfinding visualizer</h1></p>


<p align="center">
  <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/honzaap/GitHubCity?color=2411ed&style=flat-square">
</p>


![Gif of Pathfinding](https://honzaap.github.io/Pathfinding/animation.gif)

### Available algorithms:
 * A* 
 * Djikstra's
 * BFS
 * DFS
 * Greedy

### Installation
Just clone the repository and open index.html, no compilation is needed.
